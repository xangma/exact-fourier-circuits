
typedef double T;
struct Z { T r, i; };
__device__ __forceinline__ Z load_z(const T* real,const T* imag,long long index) {
    Z z={real[index],imag[index]}; return z;
}
__device__ __forceinline__ void store_z(T* real,T* imag,long long index,Z z) {
    real[index]=z.r; imag[index]=z.i;
}
__device__ __forceinline__ void track(Z z,double& peak,unsigned long long& nans,unsigned long long& infs) {
    double parts[2]={(double)z.r,(double)z.i};
    for(int j=0;j<2;j++) {
        double part=parts[j];
        if(part!=part) nans++;
        else if(part>1.7976931348623157e308 || part<-1.7976931348623157e308) infs++;
        else {
            double magnitude=part<0 ? -part : part;
            if(magnitude>peak) peak=magnitude;
        }
    }
}
__device__ __forceinline__ Z add_z(Z x,Z y,double& peak,unsigned long long& nans,unsigned long long& infs) {
    Z z={x.r+y.r,x.i+y.i}; track(z,peak,nans,infs); return z;
}
__device__ __forceinline__ Z sub_z(Z x,Z y,double& peak,unsigned long long& nans,unsigned long long& infs) {
    Z z={x.r-y.r,x.i-y.i}; track(z,peak,nans,infs); return z;
}
__device__ __forceinline__ Z scale_z(Z x,T real,T imag,double& peak,unsigned long long& nans,unsigned long long& infs) {
    Z z={real*x.r-imag*x.i,real*x.i+imag*x.r}; track(z,peak,nans,infs); return z;
}
__device__ __forceinline__ void c_pair(Z& x,Z& y,double& peak,unsigned long long& nans,unsigned long long& infs) {
    Z d=sub_z(y,x,peak,nans,infs);
    Z t=scale_z(d,(T)0.5,(T)-0.5,peak,nans,infs);
    Z u=add_z(x,t,peak,nans,infs);
    Z v=sub_z(y,t,peak,nans,infs);
    x=u; y=v;
}
__device__ __forceinline__ void compiled_shear(int id,Z& s0,Z& s1,double& peak,unsigned long long& nans,unsigned long long& infs) {
    switch(id) {
    case 0: {
s0=scale_z(s0,(T)(-1.25),(T)(0),peak,nans,infs);
s1=scale_z(s1,(T)(0),(T)(1),peak,nans,infs);
c_pair(s0,s1,peak,nans,infs);
s0=scale_z(s0,(T)(1),(T)(-1),peak,nans,infs);
s1=scale_z(s1,(T)(1),(T)(1),peak,nans,infs);
s0=scale_z(s0,(T)(-3),(T)(0),peak,nans,infs);
s1=scale_z(s1,(T)(0),(T)(1),peak,nans,infs);
c_pair(s0,s1,peak,nans,infs);
s0=scale_z(s0,(T)(1),(T)(-1),peak,nans,infs);
s1=scale_z(s1,(T)(1),(T)(1),peak,nans,infs);
s0=scale_z(s0,(T)(2),(T)(0),peak,nans,infs);
s1=scale_z(s1,(T)(0),(T)(1),peak,nans,infs);
c_pair(s0,s1,peak,nans,infs);
s0=scale_z(s0,(T)(1),(T)(-1),peak,nans,infs);
s1=scale_z(s1,(T)(1),(T)(1),peak,nans,infs);
s0=scale_z(s0,(T)(-0.125),(T)(0),peak,nans,infs);
s1=scale_z(s1,(T)(-0.16666666666666666),(T)(0),peak,nans,infs);
s0=scale_z(s0,(T)(-0.80000000000000004),(T)(0),peak,nans,infs);
break; }
case 1: {
s0=scale_z(s0,(T)(-2.5),(T)(0),peak,nans,infs);
s1=scale_z(s1,(T)(0),(T)(1),peak,nans,infs);
c_pair(s0,s1,peak,nans,infs);
s0=scale_z(s0,(T)(1),(T)(-1),peak,nans,infs);
s1=scale_z(s1,(T)(1),(T)(1),peak,nans,infs);
s0=scale_z(s0,(T)(-3),(T)(0),peak,nans,infs);
s1=scale_z(s1,(T)(0),(T)(1),peak,nans,infs);
c_pair(s0,s1,peak,nans,infs);
s0=scale_z(s0,(T)(1),(T)(-1),peak,nans,infs);
s1=scale_z(s1,(T)(1),(T)(1),peak,nans,infs);
s0=scale_z(s0,(T)(2),(T)(0),peak,nans,infs);
s1=scale_z(s1,(T)(0),(T)(1),peak,nans,infs);
c_pair(s0,s1,peak,nans,infs);
s0=scale_z(s0,(T)(1),(T)(-1),peak,nans,infs);
s1=scale_z(s1,(T)(1),(T)(1),peak,nans,infs);
s0=scale_z(s0,(T)(-0.125),(T)(0),peak,nans,infs);
s1=scale_z(s1,(T)(-0.16666666666666666),(T)(0),peak,nans,infs);
s0=scale_z(s0,(T)(-0.40000000000000002),(T)(0),peak,nans,infs);
break; }
case 2: {
s0=scale_z(s0,(T)(-5),(T)(0),peak,nans,infs);
s1=scale_z(s1,(T)(0),(T)(1),peak,nans,infs);
c_pair(s0,s1,peak,nans,infs);
s0=scale_z(s0,(T)(1),(T)(-1),peak,nans,infs);
s1=scale_z(s1,(T)(1),(T)(1),peak,nans,infs);
s0=scale_z(s0,(T)(-3),(T)(0),peak,nans,infs);
s1=scale_z(s1,(T)(0),(T)(1),peak,nans,infs);
c_pair(s0,s1,peak,nans,infs);
s0=scale_z(s0,(T)(1),(T)(-1),peak,nans,infs);
s1=scale_z(s1,(T)(1),(T)(1),peak,nans,infs);
s0=scale_z(s0,(T)(2),(T)(0),peak,nans,infs);
s1=scale_z(s1,(T)(0),(T)(1),peak,nans,infs);
c_pair(s0,s1,peak,nans,infs);
s0=scale_z(s0,(T)(1),(T)(-1),peak,nans,infs);
s1=scale_z(s1,(T)(1),(T)(1),peak,nans,infs);
s0=scale_z(s0,(T)(-0.125),(T)(0),peak,nans,infs);
s1=scale_z(s1,(T)(-0.16666666666666666),(T)(0),peak,nans,infs);
s0=scale_z(s0,(T)(-0.20000000000000001),(T)(0),peak,nans,infs);
break; }
case 3: {
s0=scale_z(s0,(T)(1.0565890622713305e+271),(T)(0),peak,nans,infs);
s1=scale_z(s1,(T)(0),(T)(1),peak,nans,infs);
c_pair(s0,s1,peak,nans,infs);
s0=scale_z(s0,(T)(1),(T)(-1),peak,nans,infs);
s1=scale_z(s1,(T)(1),(T)(1),peak,nans,infs);
s0=scale_z(s0,(T)(-3),(T)(0),peak,nans,infs);
s1=scale_z(s1,(T)(0),(T)(1),peak,nans,infs);
c_pair(s0,s1,peak,nans,infs);
s0=scale_z(s0,(T)(1),(T)(-1),peak,nans,infs);
s1=scale_z(s1,(T)(1),(T)(1),peak,nans,infs);
s0=scale_z(s0,(T)(2),(T)(0),peak,nans,infs);
s1=scale_z(s1,(T)(0),(T)(1),peak,nans,infs);
c_pair(s0,s1,peak,nans,infs);
s0=scale_z(s0,(T)(1),(T)(-1),peak,nans,infs);
s1=scale_z(s1,(T)(1),(T)(1),peak,nans,infs);
s0=scale_z(s0,(T)(-0.125),(T)(0),peak,nans,infs);
s1=scale_z(s1,(T)(-0.16666666666666666),(T)(0),peak,nans,infs);
s0=scale_z(s0,(T)(9.4644174893341982e-272),(T)(0),peak,nans,infs);
break; }
case 4: {
s0=scale_z(s0,(T)(5),(T)(0),peak,nans,infs);
s1=scale_z(s1,(T)(0),(T)(1),peak,nans,infs);
c_pair(s0,s1,peak,nans,infs);
s0=scale_z(s0,(T)(1),(T)(-1),peak,nans,infs);
s1=scale_z(s1,(T)(1),(T)(1),peak,nans,infs);
s0=scale_z(s0,(T)(-3),(T)(0),peak,nans,infs);
s1=scale_z(s1,(T)(0),(T)(1),peak,nans,infs);
c_pair(s0,s1,peak,nans,infs);
s0=scale_z(s0,(T)(1),(T)(-1),peak,nans,infs);
s1=scale_z(s1,(T)(1),(T)(1),peak,nans,infs);
s0=scale_z(s0,(T)(2),(T)(0),peak,nans,infs);
s1=scale_z(s1,(T)(0),(T)(1),peak,nans,infs);
c_pair(s0,s1,peak,nans,infs);
s0=scale_z(s0,(T)(1),(T)(-1),peak,nans,infs);
s1=scale_z(s1,(T)(1),(T)(1),peak,nans,infs);
s0=scale_z(s0,(T)(-0.125),(T)(0),peak,nans,infs);
s1=scale_z(s1,(T)(-0.16666666666666666),(T)(0),peak,nans,infs);
s0=scale_z(s0,(T)(0.20000000000000001),(T)(0),peak,nans,infs);
break; }
case 5: {
s0=scale_z(s0,(T)(2.5),(T)(0),peak,nans,infs);
s1=scale_z(s1,(T)(0),(T)(1),peak,nans,infs);
c_pair(s0,s1,peak,nans,infs);
s0=scale_z(s0,(T)(1),(T)(-1),peak,nans,infs);
s1=scale_z(s1,(T)(1),(T)(1),peak,nans,infs);
s0=scale_z(s0,(T)(-3),(T)(0),peak,nans,infs);
s1=scale_z(s1,(T)(0),(T)(1),peak,nans,infs);
c_pair(s0,s1,peak,nans,infs);
s0=scale_z(s0,(T)(1),(T)(-1),peak,nans,infs);
s1=scale_z(s1,(T)(1),(T)(1),peak,nans,infs);
s0=scale_z(s0,(T)(2),(T)(0),peak,nans,infs);
s1=scale_z(s1,(T)(0),(T)(1),peak,nans,infs);
c_pair(s0,s1,peak,nans,infs);
s0=scale_z(s0,(T)(1),(T)(-1),peak,nans,infs);
s1=scale_z(s1,(T)(1),(T)(1),peak,nans,infs);
s0=scale_z(s0,(T)(-0.125),(T)(0),peak,nans,infs);
s1=scale_z(s1,(T)(-0.16666666666666666),(T)(0),peak,nans,infs);
s0=scale_z(s0,(T)(0.40000000000000002),(T)(0),peak,nans,infs);
break; }
case 6: {
s0=scale_z(s0,(T)(1.25),(T)(0),peak,nans,infs);
s1=scale_z(s1,(T)(0),(T)(1),peak,nans,infs);
c_pair(s0,s1,peak,nans,infs);
s0=scale_z(s0,(T)(1),(T)(-1),peak,nans,infs);
s1=scale_z(s1,(T)(1),(T)(1),peak,nans,infs);
s0=scale_z(s0,(T)(-3),(T)(0),peak,nans,infs);
s1=scale_z(s1,(T)(0),(T)(1),peak,nans,infs);
c_pair(s0,s1,peak,nans,infs);
s0=scale_z(s0,(T)(1),(T)(-1),peak,nans,infs);
s1=scale_z(s1,(T)(1),(T)(1),peak,nans,infs);
s0=scale_z(s0,(T)(2),(T)(0),peak,nans,infs);
s1=scale_z(s1,(T)(0),(T)(1),peak,nans,infs);
c_pair(s0,s1,peak,nans,infs);
s0=scale_z(s0,(T)(1),(T)(-1),peak,nans,infs);
s1=scale_z(s1,(T)(1),(T)(1),peak,nans,infs);
s0=scale_z(s0,(T)(-0.125),(T)(0),peak,nans,infs);
s1=scale_z(s1,(T)(-0.16666666666666666),(T)(0),peak,nans,infs);
s0=scale_z(s0,(T)(0.80000000000000004),(T)(0),peak,nans,infs);
break; }
case 7: {
s0=scale_z(s0,(T)(1),(T)(0),peak,nans,infs);
s1=scale_z(s1,(T)(0),(T)(1),peak,nans,infs);
c_pair(s0,s1,peak,nans,infs);
s0=scale_z(s0,(T)(1),(T)(-1),peak,nans,infs);
s1=scale_z(s1,(T)(1),(T)(1),peak,nans,infs);
s0=scale_z(s0,(T)(-3),(T)(0),peak,nans,infs);
s1=scale_z(s1,(T)(0),(T)(1),peak,nans,infs);
c_pair(s0,s1,peak,nans,infs);
s0=scale_z(s0,(T)(1),(T)(-1),peak,nans,infs);
s1=scale_z(s1,(T)(1),(T)(1),peak,nans,infs);
s0=scale_z(s0,(T)(2),(T)(0),peak,nans,infs);
s1=scale_z(s1,(T)(0),(T)(1),peak,nans,infs);
c_pair(s0,s1,peak,nans,infs);
s0=scale_z(s0,(T)(1),(T)(-1),peak,nans,infs);
s1=scale_z(s1,(T)(1),(T)(1),peak,nans,infs);
s0=scale_z(s0,(T)(-0.125),(T)(0),peak,nans,infs);
s1=scale_z(s1,(T)(-0.16666666666666666),(T)(0),peak,nans,infs);
s0=scale_z(s0,(T)(1),(T)(0),peak,nans,infs);
break; }
case 8: {
s0=scale_z(s0,(T)(0.625),(T)(0),peak,nans,infs);
s1=scale_z(s1,(T)(0),(T)(1),peak,nans,infs);
c_pair(s0,s1,peak,nans,infs);
s0=scale_z(s0,(T)(1),(T)(-1),peak,nans,infs);
s1=scale_z(s1,(T)(1),(T)(1),peak,nans,infs);
s0=scale_z(s0,(T)(-3),(T)(0),peak,nans,infs);
s1=scale_z(s1,(T)(0),(T)(1),peak,nans,infs);
c_pair(s0,s1,peak,nans,infs);
s0=scale_z(s0,(T)(1),(T)(-1),peak,nans,infs);
s1=scale_z(s1,(T)(1),(T)(1),peak,nans,infs);
s0=scale_z(s0,(T)(2),(T)(0),peak,nans,infs);
s1=scale_z(s1,(T)(0),(T)(1),peak,nans,infs);
c_pair(s0,s1,peak,nans,infs);
s0=scale_z(s0,(T)(1),(T)(-1),peak,nans,infs);
s1=scale_z(s1,(T)(1),(T)(1),peak,nans,infs);
s0=scale_z(s0,(T)(-0.125),(T)(0),peak,nans,infs);
s1=scale_z(s1,(T)(-0.16666666666666666),(T)(0),peak,nans,infs);
s0=scale_z(s0,(T)(1.6000000000000001),(T)(0),peak,nans,infs);
break; }
    }
}
__device__ __forceinline__ void checkpoint(const T* real,const T* imag,T* checkpoints_real,T* checkpoints_imag,
                                          int checkpoint_id,int roles,int width,int address) {
    long long base=(long long)checkpoint_id*roles*width;
    for(int role=0;role<roles;role++) {
        long long index=(long long)role*width+address;
        checkpoints_real[base+index]=real[index];
        checkpoints_imag[base+index]=imag[index];
    }
}

extern "C" __global__ void isolated(const T* inputs,const int* ids,const T* coefficients,
 const T* normalizers,T* outputs,double* peaks,unsigned long long* nan_events,
 unsigned long long* inf_events,int count,int variant,int one_id) {
 int k=blockIdx.x*blockDim.x+threadIdx.x; if(k>=count) return;
 Z s0={inputs[4*k],inputs[4*k+1]},s1={inputs[4*k+2],inputs[4*k+3]};
 double peak=0; unsigned long long nans=0,infs=0;
 track(s0,peak,nans,infs); track(s1,peak,nans,infs);
 T t=coefficients[k],scale=normalizers[k];
 if(variant==0) s0=add_z(s0,scale_z(s1,t,(T)0,peak,nans,infs),peak,nans,infs);
 else {
   if(variant==2) {
     s0=scale_z(s0,scale,(T)0,peak,nans,infs);
     s1=scale_z(s1,scale,(T)0,peak,nans,infs);
   }
   if(variant==3) s1=scale_z(s1,t,(T)0,peak,nans,infs);
   compiled_shear(variant==3 ? one_id : ids[k],s0,s1,peak,nans,infs);
   if(variant==3) {s1.r/=t; s1.i/=t; track(s1,peak,nans,infs);}
   if(variant==2) {
     s0.r/=scale; s0.i/=scale; s1.r/=scale; s1.i/=scale;
     track(s0,peak,nans,infs); track(s1,peak,nans,infs);
   }
 }
 outputs[4*k]=s0.r;outputs[4*k+1]=s0.i;outputs[4*k+2]=s1.r;outputs[4*k+3]=s1.i;
 peaks[k]=peak;nan_events[k]=nans;inf_events[k]=infs;
}
